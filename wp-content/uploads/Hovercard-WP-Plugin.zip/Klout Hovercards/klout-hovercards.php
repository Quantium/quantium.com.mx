<?php
/*
Plugin Name: Klout Hovercards
Plugin URI: http://klout.com
Description: Adds klout hovercards to every klout.com/username a tag on a blog
Version: 1.0
Author: tykelewis
Author URI: http://klout.com
License: GPL
*/

add_action('wp_head','add_klout');

function add_klout(){
	print '<script src="http://klout.com/public/scripts/widget_hover.js" type="text/javascript"></script>';
}