=== Plugin Name ===
Contributors: tykelewis
Tags: klout,hovercards
Requires at least: 2.0.2
Tested up to: 2.1
Stable tag: 4.3

== Description ==

Adds klout hovercards to every klout.com/username a tag on a blog